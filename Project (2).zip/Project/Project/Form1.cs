﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/*This is a project called Shakespeare Kinetic Novel Constructor,
 It can be used to edit and view Kinetic Novelizations of Shakepearian plays*/


namespace Project1
{
    public partial class Form1 : Form
    {
        string directory = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
        string path;
        string[] dialogue;  
        string[] players;
        int[] checkpoints;
        int[] scenes;
        int[] acts;
        string[] imagelocations;
        string[] scenelocations;
        int pos = 0;
        string playname;
        bool Shakespeare;
        bool editted = false;
        string destpath;
        public Form1()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.Text = "Kinetic Novel Constructor";
            this.StartPosition = FormStartPosition.CenterScreen;
            pictureBox1.Parent = Background;
            pictureBox2.Parent = Background;
            pictureBox3.Parent = Background;
            label5.Parent = Background;
            label6.Parent = Background;




        }
        /******************************PANEL 1*******************************************************************************************/
        /*Located on Panel 1, Button 1 takes user to Panel 2.*/
        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        /*Located on Panel 1, Button 2 is the exit program button*/
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /**********************************************************************************************************************************/

        /*Located on Panel 2, Button 3 is the Select Play Button */
        private void button3_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;

        }

        /*Located on Panel 2, Button 4 is the back button.  Takes user back to main menu*/
        private void button4_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;

        }

        /**********************************************************************************************************************************/
        /*PANEL 3 - SELECTING A PLAY*/

        /* Button 5 is a back button, it takes the user back to panel 2 the */
        private void button5_Click_1(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }

        /* Add a play to the list of non-Shakespeare plays --Currently does not save addition upon shut down */
        private void Addplay_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text|*.txt|All|*.*";
            string name;


            if (this.openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // var fileName = this.openFileDialog1.FileName;
                name = this.openFileDialog1.FileName;
                // name = temp;
                // string destFile = Path.Combine(destpath, name);
                listBox1.Items.Add(name);
            }

        }

        /* USed for selecting a user input play from the listbox
         Selected play will be used as the current play*/
        private void SelectChecked_Click(object sender, EventArgs e)
        {
            string[] temp;
            string source = listBox1.SelectedItem.ToString();
            string file = source.Split('\\').Last();
            temp = File.ReadAllLines(source);
            string newpath = directory + @"\Added\" ;
            string newfile = (newpath + "\\" + file);

            using (StreamWriter sw = new StreamWriter(newfile))
            {
                for (int i = 0; i < temp.Length; i++)
                { sw.WriteLine(temp[i]); }
            }
            playname = file;
            if (editted)
            {
                try
                {
                    dialogue = File.ReadAllLines(directory + @"\Edits\" + playname + ".txt");
                }
                catch {
                    path = newfile;
                    dialogue = File.ReadAllLines(path);
                }
                
            }
            else
            {
                path = newfile;
                dialogue = File.ReadAllLines(path);
            }

            Populate(dialogue);
            panel4.Visible = true;
           
            Shakespeare = false;

        }

        /**********************************************************************************************************************************/

        /*Back button on panel 4 takes user back to panel 2*/
        private void back2select_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
            panel3.Visible = false;

        }
        /*User can use this button to find more information about the play - only works for Shakespeare plays*/
        private void About_Click(object sender, EventArgs e)
        {
            if (Shakespeare)
                System.Diagnostics.Process.Start("https://www.bing.com/search?q=about+shakespeare+" + playname);

        }


        /* Initiates viewer, user will view the play in a kinetic novel style*/
        private void Viewer_Click(object sender, EventArgs e)
        {
            panel5.Visible = true;
            label5.BackColor = Color.Transparent;
            label6.BackColor = Color.Transparent;
            Background.Image = Properties.Resources.bg;
        
        }


        string act = "ACT";
        string scene = "SCENE";

        /*Forward button - user advances the text*/
        private void Forward_Click(object sender, EventArgs e)
        {
            StageDirections.Hide();
            if (pos < dialogue.Length)
            {
                if (dialogue[pos] == "")
                { pos = pos + 1; }
                try
                {
                    if (dialogue[pos].Contains(act))
                    {
                        label5.Text = dialogue[pos];
                        pos = pos + 1;
                    }
                }
                catch { }
                try
                {
                    if (dialogue[pos].Contains(scene))
                    {
                        try
                        {
                            int n = 0;
                            while (scenes[n] <= pos && n + 1 < scenes.Length)
                            { n = n + 1; }
                       
                        label6.Text = dialogue[pos];
                            pos = pos + 1;
                            Background.Image = ResizeImage(Image.FromFile(scenelocations[n-1]), true);
                        
                          
                        }
                        catch { Background.Image = ResizeImage(Properties.Resources.bg, true); }
                    }
                }
                catch { }
                try
                {
                    if (ContainsSD(dialogue[pos]))
                    {
                        if (dialogue[pos].Contains("Exit") || dialogue[pos].Contains("Exeunt"))
                        {
                            pictureBox1.Image = ResizeImage(Properties.Resources.transparency, false); pictureBox1.BackColor = Color.Transparent; 
                            pictureBox2.Image = ResizeImage(Properties.Resources.transparency, false); pictureBox2.BackColor = Color.Transparent;
                        }
                        StageDirections.Show();
                        StageDirections.Text = dialogue[pos];
                        if (dialogue[pos + 1] == "")
                        {
                            pos = pos + 1;
                        }
                        pos = pos + 1;
                    }

                }
                catch { }
                try
                {
                    if (IsAllUpper(dialogue[pos]))
                    {
                        NameBox.Text = dialogue[pos];
                        
                            for(int index = 0; index < players.Length; index++)
                            {
                               

                                if (players[index] == NameBox.Text)
                                {
                                try
                                {
                                   
                                    pictureBox1.Visible = true;
                                    pictureBox2.Visible = true;
                                    //pictureBox3.Visible = true;
                                    pictureBox1.Image = pictureBox2.Image;
                                    //pictureBox3.Image = pictureBox2.Image;
                                    try
                                    {
                                        pictureBox2.Image = ResizeImage(Image.FromFile(imagelocations[index]), false);
                                    }
                                    catch { pictureBox2.Image = ResizeImage(Properties.Resources.lear, false); }
                                   // pictureBox3.BackColor = Color.Transparent;
                                    pictureBox1.BackColor = Color.Transparent;
                                    pictureBox2.BackColor = Color.Transparent;

                                    index = players.Length;
                                }
                                catch
                                {
                                    pictureBox1.Image = ResizeImage(Properties.Resources.transparency, false); pictureBox1.BackColor = Color.Transparent;
                                    pictureBox2.Image = ResizeImage(Properties.Resources.transparency, false); pictureBox2.BackColor = Color.Transparent;
                                }
                            }

                            }
                  

                        if (dialogue[pos + 1] == "")
                        { pos = pos + 1; }



                        dialoguebox.Text = dialogue[pos + 1];
                        pos = pos + 1;
                    }
                    else dialoguebox.Text = dialogue[pos];
                }
                catch { }
                pos = pos + 1;
            }
         
        }

        /*Back button.  Takes user to the initiation of previous speaker's dialogue*/
        private void Back_Click(object sender, EventArgs e)
        {   
            bool begin = false;
            int k = 0;
            int m = 0;
            int n = 0;
            try
            {
                while (checkpoints[k] < pos && k + 1 < checkpoints.Length)
                { k = k + 1; }
            }
            catch { }
            try
            {
                while (acts[m] < pos && m + 1 < acts.Length)
                { m = m + 1; }
            }
            catch { }
            try
            {
                while (scenes[n] < pos && n + 1 < scenes.Length)
                { n = n + 1; }
            }
            catch { }
            try
            {
                pos = checkpoints[k - 2];
                if (pos < scenes[n - 1])
                { try { label6.Text = dialogue[scenes[n - 2]]; } catch { } }
                if (pos < acts[m - 1])
                { try { label5.Text = dialogue[acts[m - 2]]; } catch { } }
            }
            catch { begin = true; }
            if (begin == false)
            {
                if (dialogue[pos] == "")
                { pos = pos + 1; }

                if (IsAllUpper(dialogue[pos]))
                {
                   
                    NameBox.Text = dialogue[pos];
                    if (dialogue[pos + 1] == "")
                    { pos = pos + 1; }

                    dialoguebox.Text = dialogue[pos + 1];
                    pos = pos + 1;
                }
                else dialoguebox.Text = dialogue[pos];

                pos = pos + 1;
            }
        }

        /*Allows user to view entire script while in viewer mode*/
        private void View_Click(object sender, EventArgs e)
        {
            StageDirections.Hide();
            listBox2.Items.Clear();
            listBox2.Visible = true;
            Jump.Visible = true;
            CloselistBox2.Visible = true;

            foreach (string line in dialogue)
                listBox2.Items.Add(line);
            

            
        }
        /*Exits the viewer mode - takes user back to panel 4*/
        private void ExitViewer_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
            pos = 0;
            dialoguebox.Clear();
            NameBox.Clear();
            label5.Text = "";
            label6.Text = "";
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox1.Image = ResizeImage(Properties.Resources.transparency, false); pictureBox1.BackColor = Color.Transparent;
            pictureBox2.Image = ResizeImage(Properties.Resources.transparency, false); pictureBox2.BackColor = Color.Transparent;
            StageDirections.Hide();
        }

        /* // gets and uses pos value of line selected in script, and jumps to that point*/
        private void Jump_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            int temp = 0;
            NameBox.Clear();
            dialoguebox.Clear();
            pos = 0;
            temp = listBox2.SelectedIndex;
           
            listBox2.Visible = false;
            Jump.Visible = false;
            CloselistBox2.Visible = false;
           

            for ( pos = 0; pos <= temp; pos++)
            {
                if (dialogue[pos] == "")
                { pos = pos + 1; }
                if (dialogue[pos].Contains(act))
                {
                    label5.Text = dialogue[pos];
                    pos = pos + 1;
                }
                if (dialogue[pos].Contains(scene))
                {
                    try
                    {
                        int n = 0;
                        while (scenes[n] <= pos && n + 1 < scenes.Length)
                        { n = n + 1; }

                        label6.Text = dialogue[pos];
                        pos = pos + 1;
                        Background.Image = ResizeImage(Image.FromFile(scenelocations[n - 1]), true);


                    }
                    catch { Background.Image = ResizeImage(Properties.Resources.bg, true); }
                }
                if (IsAllUpper(dialogue[pos]))
                {
                    NameBox.Text = dialogue[pos];

                    if (dialogue[pos + 1] == "")
                    { pos = pos + 1; }

                    dialoguebox.Text = dialogue[pos + 1];
                    pos = pos + 1;
                }
                else dialoguebox.Text = dialogue[pos];

                
            }

        }

        /*Closes the script view while in viewer mode*/
        private void CloselistBox2_Click(object sender, EventArgs e)
        {
           
            listBox2.Visible = false;
            Jump.Visible = false;
            CloselistBox2.Visible = false;
        }


        /**********************************************************************************************************************************/
        /*A method for checking if a line of input is all caps.*/
        bool IsAllUpper(string input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (Char.IsUpper(input[i]) || input[i] == ' ')
                { }
                else
                    if (Char.IsLower(input[i]))
                    return false;
            }

            return true;
        }

        /*A method for checking if a line of input contains stage directions.*/
        bool ContainsSD(string input)
        {

            for (int q = 0; q < players.Length; q++)
            {
                if (input.Contains("Enter") && input.Contains(players[q]))
                {

                    return true;
                }
                if (input.Contains("Exit") && input.Contains(players[q]))
                {

                    return true;
                }
                if (input.Contains("Exit") && !input.Contains(" "))
                {
                    return true;
                }
                if (input.Contains("Exeunt"))
                {
                    return true;
                }
                if (input.Contains(players[q]) && !IsAllUpper(input))
                { return true; }

            }
            return false;
        }

        /*A method tha takes an image and resizes to either the size of the window if bg is true, or to the size of the viewer's picture box if bg is false.*/
        public static Bitmap ResizeImage(Image image, bool bg)
        {
            Bitmap result = new Bitmap(560, 1050);
            int w;
            int h;
            double d = (double)image.Width / (double)image.Height;
            if (bg == true)
            {

                w = 1050;
                h = 560;
                result = new Bitmap(w, h);

                // prevents image from blurring.
                using (Graphics graphics = Graphics.FromImage(result))
                {
                    graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                    graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                    graphics.DrawImage(image, 0, 0, result.Width, result.Height);
                }


                return result;
            }
            else
            {
                if ((int)((double)525 * d) < 315)
                {
                    w = (int)(525 * d);
                    h = (525);
                    result = new Bitmap(w, h);
                }
                else
                {
                    w = 315;
                    h = (int)(315 / d);
                    result = new Bitmap(w, h);
                }
                // prevents image from blurring.
                using (Graphics graphics = Graphics.FromImage(result))
                {
                    graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                    graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                    graphics.DrawImage(image, 0, 0, result.Width, result.Height);
                }

                return result;
            }
        }

        /*Method takes an array of strings -- the playscript -- and populates other smaller arrays, the character list, scene list, etc.*/
        public void Populate(string[] strings)
        {
            List<int> actList = new List<int>();
            List<int> sceneList = new List<int>();
            List<int> cps = new List<int>();
          
            int j = 0;
             for (int i = 0; i < strings.Length; i++)
             {
                if (strings[i] == "")
                {  }
               else
               if (IsAllUpper(strings[i]) && strings[i].Contains(act) == false && strings[i].Contains(scene) == false)
                {
                    cps.Add(i);
                 
                    j = j + 1;
                }
                if (strings[i].Contains(scene))
                { sceneList.Add(i); }
                if (strings[i].Contains(act))
                { actList.Add(i); }
            }
            checkpoints = cps.ToArray();
            scenes = sceneList.ToArray();
            acts = actList.ToArray();
            
            string[] tmp = new string[checkpoints.Length];
            string[] tmp2 = new string[tmp.Length];

            for (int a = 0; a < checkpoints.Length; a++)
            {
                
                tmp[a] = dialogue[checkpoints[a]]; 
            }

            tmp2 = tmp.Distinct().ToArray();
            players = new string[tmp2.Length];
            int p = 0;
            for (int b = 0; b < tmp2.Length; b++)
            {
                bool partOf = false;
                for (int c = 0; c < tmp2.Length; c++)
                {
                    if (c != b)
                    {
                        if (tmp2[b].Contains(tmp2[c]) || (tmp2[b].Contains(":")))
                        {
                            partOf = true;
                        }
                        
                    }
                   
                }
                if (partOf) { }
                else
                {
                    if (tmp2[b] != null || tmp2[b] != "")
                    { players[p] = tmp2[b]; p++; }
                }
                imagelocations = new string[players.Length];
                scenelocations = new string[scenes.Length];
            }

            
        }
        /************************************************************************************************************************************************************************/

        /*Edit Panel*/
        /*Takes user to panel 6 the edit panel*/
        private void Editor_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
        }

        bool p ;
        bool s ;

        /*Shows the list of characters in the play, and a preview box that shows the assigned image for the selected character.*/
        private void editplayers_Click(object sender, EventArgs e)
        {
            listBox3.Visible = true;
            p = true;
            s = false;
            previewBox.Visible = false;
            Script.Visible = false;
            scriptbutton.Visible = false;
            Default.Visible = false;
            listBox3.Items.Clear();
            foreach (string str in players)
             {
                 if (string.IsNullOrEmpty(str) == false || string.IsNullOrWhiteSpace(str) == false)

                 { listBox3.Items.Add(str ); }
             }

        }
        
        /*Shows the list of scenes in the play, and a preview box that shows the assined image for each setting */
        private void editsettings_Click(object sender, EventArgs e)
        {
            listBox3.Visible = true;
            s = true;
            p = false;
            previewBox.Visible = false;
            Script.Visible = false;
            scriptbutton.Visible = false;
            Default.Visible = false;
            listBox3.Items.Clear();
            for (int z = 0; z < scenes.Length; z++)
            {
                listBox3.Items.Add(dialogue[scenes[z]]);
            }
        }

        /*When a different selection is made in the lists of scenes and characters, the image preview updates to show the corresponding image for the selection.*/
        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            previewBox.Visible = true;
            imageedit.Visible = true;
            try
            {
                if (p) { previewBox.Image = ResizeImage(Image.FromFile(imagelocations[listBox3.SelectedIndex]), false); }
            }
            catch { previewBox.Image = ResizeImage(Properties.Resources.lear, false); }

            try
            {
                if (s) { previewBox.Image = ResizeImage(Image.FromFile(scenelocations[listBox3.SelectedIndex]), false); }
            }
            catch { previewBox.Image = ResizeImage(Properties.Resources.bg, false); }
        }

        /*Allows user to change the image associated with a particular character or scene.*/
        private void imageedit_Click(object sender, EventArgs e)
        {
            string imagepath;
            openFileDialog2.Filter = "Image Files|*.jpg;*.jpeg;*.png";
            if (this.openFileDialog2.ShowDialog() == DialogResult.OK)
            {

                imagepath = this.openFileDialog2.FileName;
                if (p)
                {
                    imagelocations[listBox3.SelectedIndex] = imagepath;
                    previewBox.Image = ResizeImage(Image.FromFile(imagepath),  false);
                }
                if (s)
                {
                    scenelocations[listBox3.SelectedIndex] = imagepath;
                    previewBox.Image = ResizeImage(Image.FromFile(imagepath),  false);
                }
            }
        }

        /*Takes user back to panel 4*/
        private void backfromedit_Click(object sender, EventArgs e)
        {
            scriptbutton.Visible = false;
            Script.Visible = false;
            panel6.Visible = false;
            Default.Visible = false;
            previewBox.Visible = false;
            listBox3.Visible = false;
            imageedit.Visible = false;
          
        }
        
        /*Opens an editable richTextBox with the contents of the current script. */
        private void editscript_Click(object sender, EventArgs e)
        {
            previewBox.Visible = false;
            Default.Visible = true;
            imageedit.Visible = false;
            Script.Visible = true;
            scriptbutton.Visible = true;
            if (editted)
            { try { Script.Text = File.ReadAllText(destpath + "\\" + playname + ".txt"); } catch { Script.Text = File.ReadAllText(path); } }
            else
            {
                Script.Text = File.ReadAllText(path);
            }  
        }

        /*Allows user to save the changes they have made to the current script.*/
        private void scriptbutton_Click(object sender, EventArgs e)
        {
            string[] editd = Script.Text.Split('\n');
            
                destpath = directory + @"\Edits";
                string editpath = destpath + "\\" + playname + ".txt";
                using (StreamWriter sw = new StreamWriter(editpath))
                {
                    for (int i = 0; i < editd.Length; i++)
                    { sw.WriteLine(editd[i]); }
                }
                dialogue = File.ReadAllLines(editpath);
                Populate(dialogue);
                Script.Clear();
                Script.Visible = false;
                scriptbutton.Visible = false;
                Default.Visible = false;
                editted = true;
                
        }

        /*Removes the changes made by the user, and sets current script back to its default/original text*/
        private void Default_Click(object sender, EventArgs e)
        {  
          var confirm =  MessageBox.Show("Remove all changes and revert to default?", "Yes No", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                dialogue = File.ReadAllLines(path);
                Populate(dialogue);
                Script.Text = File.ReadAllText(path);
                File.Delete(destpath + "\\" + playname + ".txt");
            }
        }

        /***************************************************************************************************************************************************************************/
        /************************************************* Play buttons ************************************************************************************************************/
        /***************************************************************************************************************************************************************************/

        /*Located on Panel 3: Allows user to select the play: Hamlet*/
        private void Hamlet_Click(object sender, EventArgs e)
        {
            playname = "Hamlet";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; ;
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; ;
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Macbeth*/
        private void Macbeth_Click(object sender, EventArgs e)
        {
            playname = "Macbeth";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt";
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt";
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: All's Well That Ends Well*/
        private void AllsWell_Click(object sender, EventArgs e)
        {
            playname = "All's Well That Ends Well";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Antony and Cleopatra*/
        private void AntonyandCleopatra_Click(object sender, EventArgs e)
        {
            playname = "Antony and Cleopatra";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: As You Like It*/
        private void AsYouLikeIt_Click(object sender, EventArgs e)
        {
            playname = "As You Like It";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: The Comedy of Errors*/
        private void ComedyofErrors_Click(object sender, EventArgs e)
        {
            playname = "The Comedy of Errors";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Coriolanus*/
        private void Coriolanus_Click(object sender, EventArgs e)
        {
            playname = "Coriolanus";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Cymbeline*/
        private void Cymbeline_Click(object sender, EventArgs e)
        {
            playname = "Cymbeline";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Two Gentlemen of Verona*/
        private void GentlemenofVerona_Click(object sender, EventArgs e)
        {
            playname = "Two Gentlemen of Verona";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Henry IV part 1*/
        private void Henry4part1_Click(object sender, EventArgs e)
        {
            playname = "Henry IV part 1";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Henry IV part 2*/
        private void Henry4part2_Click(object sender, EventArgs e)
        {
            playname = "Henry IV part 2";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Henry V*/
        private void Henry5_Click(object sender, EventArgs e)
        {
            playname = "Henry V";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Henry VI part 1*/
        private void Henry6part1_Click(object sender, EventArgs e)
        {
            playname = "Henry VI part 1";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Henry VI part 2*/
        private void Henry6part2_Click(object sender, EventArgs e)
        {
            playname = "Henry VI part 2";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Henry VI part 3*/
        private void Henry6part3_Click(object sender, EventArgs e)
        {
            playname = "Henry VI part 3";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Henry VIII*/
        private void Henry8_Click(object sender, EventArgs e)
        {
            playname = "Henry VIII";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Julius Caesar*/
        private void JuliusCaesar_Click(object sender, EventArgs e)
        {
            playname = "Julius Caesar";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: King John*/
        private void KingJohn_Click(object sender, EventArgs e)
        {
            playname = "King John";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: King Lear*/
        private void KingLear_Click(object sender, EventArgs e)
        {
            playname = "King Lear";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Loves Labours Lost*/
        private void LovesLaboursLost_Click(object sender, EventArgs e)
        {
            playname = "Loves Labours Lost";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Merchant of Venice*/
        private void MerchantofVenice_Click(object sender, EventArgs e)
        {
            playname = "The Merchant of Venice";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: The Merry Wives of Windsor*/
        private void MerryWives_Click(object sender, EventArgs e)
        {
            playname = "The Merry Wives of Windsor";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt";
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: A Midsummer Night's Dream*/
        private void MidsummerNights_Click(object sender, EventArgs e)
        {
            playname = "A Midsummer Night's Dream";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Much Ado About Nothing*/
        private void MuchAdo_Click(object sender, EventArgs e)
        {
            playname = "Much Ado About Nothing";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Othello*/
        private void Othello_Click(object sender, EventArgs e)
        {
            playname = "Othello";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Pericles, Prince of Tyre*/
        private void Pericles_Click(object sender, EventArgs e)
        {
            playname = "Pericles, Prince of Tyre";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Richard II*/
        private void Richardsecond_Click(object sender, EventArgs e)
        {
            playname = "Richard II";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Richard III*/
        private void Richardthird_Click(object sender, EventArgs e)
        {
            playname = "Richard III";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Romeo and Juliet*/
        private void RomeoJuliet_Click(object sender, EventArgs e)
        {
            playname = "Romeo and Juliet";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: The Taming of the Shrew*/
        private void TamingoftheShrew_Click(object sender, EventArgs e)
        {
            playname = "The Taming of the Shrew";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: The Tempest*/
        private void TheTempest_Click(object sender, EventArgs e)
        {
            playname = "The Tempest";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Timon of Athens*/
        private void TimonofAthens_Click(object sender, EventArgs e)
        {
            playname = "Timon of Athens";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Titus Andronicus*/
        private void TitusAndronicus_Click(object sender, EventArgs e)
        {
            playname = "Titus Andronicus";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Troilus and Cressida*/
        private void TroilusandCressida_Click(object sender, EventArgs e)
        {
            playname = "Troilus and Cressida";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Twelfth Night*/
        private void TwelfthNight_Click(object sender, EventArgs e)
        {
            playname = "Twelfth Night";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }

        /*Located on Panel 3: Allows user to select the play: Winter's Tale*/
        private void WintersTale_Click(object sender, EventArgs e)
        {
            playname = "Winter's Tale";
            if (editted)
            {
                try
                {
                    string destfile = directory + @"\Edits\" + playname + ".txt";
                    dialogue = File.ReadAllLines(destfile);
                }
                catch
                {
                    try
                    {
                        path = directory + @"\Plays\" + playname + ".txt";
                        dialogue = File.ReadAllLines(path);
                    }
                    catch { MessageBox.Show("Files Missing"); }
                }
            }
            else
            {
                try
                {
                    path = directory + @"\Plays\" + playname + ".txt"; 
                    dialogue = File.ReadAllLines(path);
                }
                catch { MessageBox.Show("Files Missing"); }
            }
            path = directory + @"\Plays\" + playname + ".txt"; 
            Populate(dialogue);
            panel4.Visible = true;
            Shakespeare = true;
        }
    }
}
