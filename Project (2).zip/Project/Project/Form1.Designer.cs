﻿namespace Project1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.imageedit = new System.Windows.Forms.Button();
            this.Default = new System.Windows.Forms.Button();
            this.scriptbutton = new System.Windows.Forms.Button();
            this.Script = new System.Windows.Forms.RichTextBox();
            this.previewBox = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.editscript = new System.Windows.Forms.Button();
            this.backfromedit = new System.Windows.Forms.Button();
            this.editsettings = new System.Windows.Forms.Button();
            this.editplayers = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.StageDirections = new System.Windows.Forms.RichTextBox();
            this.CloselistBox2 = new System.Windows.Forms.Button();
            this.Jump = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.ExitViewer = new System.Windows.Forms.Button();
            this.View = new System.Windows.Forms.Button();
            this.NameBox = new System.Windows.Forms.TextBox();
            this.dialoguebox = new System.Windows.Forms.RichTextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Back = new System.Windows.Forms.Button();
            this.Forward = new System.Windows.Forms.Button();
            this.Background = new System.Windows.Forms.PictureBox();
            this.About = new System.Windows.Forms.Button();
            this.Editor = new System.Windows.Forms.Button();
            this.Viewer = new System.Windows.Forms.Button();
            this.back2select = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SelectChecked = new System.Windows.Forms.Button();
            this.Addplay = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.TitusAndronicus = new System.Windows.Forms.Button();
            this.TimonofAthens = new System.Windows.Forms.Button();
            this.RomeoJuliet = new System.Windows.Forms.Button();
            this.Othello = new System.Windows.Forms.Button();
            this.Macbeth = new System.Windows.Forms.Button();
            this.KingLear = new System.Windows.Forms.Button();
            this.JuliusCaesar = new System.Windows.Forms.Button();
            this.Coriolanus = new System.Windows.Forms.Button();
            this.AntonyandCleopatra = new System.Windows.Forms.Button();
            this.Richardthird = new System.Windows.Forms.Button();
            this.Richardsecond = new System.Windows.Forms.Button();
            this.KingJohn = new System.Windows.Forms.Button();
            this.Henry8 = new System.Windows.Forms.Button();
            this.Henry6part3 = new System.Windows.Forms.Button();
            this.Henry6part2 = new System.Windows.Forms.Button();
            this.Henry6part1 = new System.Windows.Forms.Button();
            this.Henry5 = new System.Windows.Forms.Button();
            this.Henry4part2 = new System.Windows.Forms.Button();
            this.Henry4part1 = new System.Windows.Forms.Button();
            this.WintersTale = new System.Windows.Forms.Button();
            this.GentlemenofVerona = new System.Windows.Forms.Button();
            this.TwelfthNight = new System.Windows.Forms.Button();
            this.TroilusandCressida = new System.Windows.Forms.Button();
            this.TheTempest = new System.Windows.Forms.Button();
            this.TamingoftheShrew = new System.Windows.Forms.Button();
            this.Pericles = new System.Windows.Forms.Button();
            this.MuchAdo = new System.Windows.Forms.Button();
            this.MidsummerNights = new System.Windows.Forms.Button();
            this.MerchantofVenice = new System.Windows.Forms.Button();
            this.MerryWives = new System.Windows.Forms.Button();
            this.LovesLaboursLost = new System.Windows.Forms.Button();
            this.Cymbeline = new System.Windows.Forms.Button();
            this.ComedyofErrors = new System.Windows.Forms.Button();
            this.AsYouLikeIt = new System.Windows.Forms.Button();
            this.AllsWell = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.Hamlet = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.previewBox)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Background)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(717, 200);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(195, 69);
            this.button1.TabIndex = 0;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1050, 635);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::Project1.Properties.Resources.panel2;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1058, 643);
            this.panel2.TabIndex = 2;
            this.panel2.Visible = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.listBox1);
            this.panel3.Controls.Add(this.SelectChecked);
            this.panel3.Controls.Add(this.Addplay);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.TitusAndronicus);
            this.panel3.Controls.Add(this.TimonofAthens);
            this.panel3.Controls.Add(this.RomeoJuliet);
            this.panel3.Controls.Add(this.Othello);
            this.panel3.Controls.Add(this.Macbeth);
            this.panel3.Controls.Add(this.KingLear);
            this.panel3.Controls.Add(this.JuliusCaesar);
            this.panel3.Controls.Add(this.Coriolanus);
            this.panel3.Controls.Add(this.AntonyandCleopatra);
            this.panel3.Controls.Add(this.Richardthird);
            this.panel3.Controls.Add(this.Richardsecond);
            this.panel3.Controls.Add(this.KingJohn);
            this.panel3.Controls.Add(this.Henry8);
            this.panel3.Controls.Add(this.Henry6part3);
            this.panel3.Controls.Add(this.Henry6part2);
            this.panel3.Controls.Add(this.Henry6part1);
            this.panel3.Controls.Add(this.Henry5);
            this.panel3.Controls.Add(this.Henry4part2);
            this.panel3.Controls.Add(this.Henry4part1);
            this.panel3.Controls.Add(this.WintersTale);
            this.panel3.Controls.Add(this.GentlemenofVerona);
            this.panel3.Controls.Add(this.TwelfthNight);
            this.panel3.Controls.Add(this.TroilusandCressida);
            this.panel3.Controls.Add(this.TheTempest);
            this.panel3.Controls.Add(this.TamingoftheShrew);
            this.panel3.Controls.Add(this.Pericles);
            this.panel3.Controls.Add(this.MuchAdo);
            this.panel3.Controls.Add(this.MidsummerNights);
            this.panel3.Controls.Add(this.MerchantofVenice);
            this.panel3.Controls.Add(this.MerryWives);
            this.panel3.Controls.Add(this.LovesLaboursLost);
            this.panel3.Controls.Add(this.Cymbeline);
            this.panel3.Controls.Add(this.ComedyofErrors);
            this.panel3.Controls.Add(this.AsYouLikeIt);
            this.panel3.Controls.Add(this.AllsWell);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Controls.Add(this.Hamlet);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1044, 629);
            this.panel3.TabIndex = 3;
            this.panel3.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = global::Project1.Properties.Resources.curtain;
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.About);
            this.panel4.Controls.Add(this.Editor);
            this.panel4.Controls.Add(this.Viewer);
            this.panel4.Controls.Add(this.back2select);
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1047, 640);
            this.panel4.TabIndex = 45;
            this.panel4.Visible = false;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.imageedit);
            this.panel6.Controls.Add(this.Default);
            this.panel6.Controls.Add(this.scriptbutton);
            this.panel6.Controls.Add(this.Script);
            this.panel6.Controls.Add(this.previewBox);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.listBox3);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.editscript);
            this.panel6.Controls.Add(this.backfromedit);
            this.panel6.Controls.Add(this.editsettings);
            this.panel6.Controls.Add(this.editplayers);
            this.panel6.Location = new System.Drawing.Point(3, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1055, 642);
            this.panel6.TabIndex = 7;
            this.panel6.Visible = false;
            // 
            // imageedit
            // 
            this.imageedit.Location = new System.Drawing.Point(741, 572);
            this.imageedit.Name = "imageedit";
            this.imageedit.Size = new System.Drawing.Size(75, 23);
            this.imageedit.TabIndex = 15;
            this.imageedit.Text = "Change";
            this.imageedit.UseVisualStyleBackColor = true;
            this.imageedit.Visible = false;
            this.imageedit.Click += new System.EventHandler(this.imageedit_Click);
            // 
            // Default
            // 
            this.Default.Location = new System.Drawing.Point(963, 28);
            this.Default.Name = "Default";
            this.Default.Size = new System.Drawing.Size(75, 41);
            this.Default.TabIndex = 14;
            this.Default.Text = "Revert to Default";
            this.Default.UseVisualStyleBackColor = true;
            this.Default.Visible = false;
            this.Default.Click += new System.EventHandler(this.Default_Click);
            // 
            // scriptbutton
            // 
            this.scriptbutton.Location = new System.Drawing.Point(963, 560);
            this.scriptbutton.Name = "scriptbutton";
            this.scriptbutton.Size = new System.Drawing.Size(75, 41);
            this.scriptbutton.TabIndex = 13;
            this.scriptbutton.Text = "Make Changes";
            this.scriptbutton.UseVisualStyleBackColor = true;
            this.scriptbutton.Visible = false;
            this.scriptbutton.Click += new System.EventHandler(this.scriptbutton_Click);
            // 
            // Script
            // 
            this.Script.Location = new System.Drawing.Point(275, 27);
            this.Script.Name = "Script";
            this.Script.Size = new System.Drawing.Size(678, 577);
            this.Script.TabIndex = 12;
            this.Script.Text = "";
            this.Script.Visible = false;
            // 
            // previewBox
            // 
            this.previewBox.Location = new System.Drawing.Point(534, 27);
            this.previewBox.Name = "previewBox";
            this.previewBox.Size = new System.Drawing.Size(507, 530);
            this.previewBox.TabIndex = 11;
            this.previewBox.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(91, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 32);
            this.label6.TabIndex = 13;
            this.label6.Text = ":";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(275, 28);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(238, 576);
            this.listBox3.TabIndex = 10;
            this.listBox3.Visible = false;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 32);
            this.label5.TabIndex = 12;
            this.label5.Text = ":";
            // 
            // editscript
            // 
            this.editscript.Location = new System.Drawing.Point(14, 212);
            this.editscript.Name = "editscript";
            this.editscript.Size = new System.Drawing.Size(195, 69);
            this.editscript.TabIndex = 9;
            this.editscript.Text = "Edit Script";
            this.editscript.UseVisualStyleBackColor = true;
            this.editscript.Click += new System.EventHandler(this.editscript_Click);
            // 
            // backfromedit
            // 
            this.backfromedit.Location = new System.Drawing.Point(14, 534);
            this.backfromedit.Name = "backfromedit";
            this.backfromedit.Size = new System.Drawing.Size(195, 69);
            this.backfromedit.TabIndex = 8;
            this.backfromedit.Text = "Back";
            this.backfromedit.UseVisualStyleBackColor = true;
            this.backfromedit.Click += new System.EventHandler(this.backfromedit_Click);
            // 
            // editsettings
            // 
            this.editsettings.Location = new System.Drawing.Point(14, 120);
            this.editsettings.Name = "editsettings";
            this.editsettings.Size = new System.Drawing.Size(195, 69);
            this.editsettings.TabIndex = 7;
            this.editsettings.Text = "Assign Scene Settings";
            this.editsettings.UseVisualStyleBackColor = true;
            this.editsettings.Click += new System.EventHandler(this.editsettings_Click);
            // 
            // editplayers
            // 
            this.editplayers.Location = new System.Drawing.Point(14, 30);
            this.editplayers.Name = "editplayers";
            this.editplayers.Size = new System.Drawing.Size(195, 69);
            this.editplayers.TabIndex = 6;
            this.editplayers.Text = "Assign Players";
            this.editplayers.UseVisualStyleBackColor = true;
            this.editplayers.Click += new System.EventHandler(this.editplayers_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.StageDirections);
            this.panel5.Controls.Add(this.CloselistBox2);
            this.panel5.Controls.Add(this.Jump);
            this.panel5.Controls.Add(this.listBox2);
            this.panel5.Controls.Add(this.ExitViewer);
            this.panel5.Controls.Add(this.View);
            this.panel5.Controls.Add(this.NameBox);
            this.panel5.Controls.Add(this.dialoguebox);
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Controls.Add(this.Back);
            this.panel5.Controls.Add(this.Forward);
            this.panel5.Controls.Add(this.Background);
            this.panel5.Location = new System.Drawing.Point(3, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1047, 640);
            this.panel5.TabIndex = 46;
            this.panel5.Visible = false;
            // 
            // StageDirections
            // 
            this.StageDirections.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StageDirections.Location = new System.Drawing.Point(202, 381);
            this.StageDirections.Name = "StageDirections";
            this.StageDirections.Size = new System.Drawing.Size(849, 36);
            this.StageDirections.TabIndex = 19;
            this.StageDirections.Text = "";
            // 
            // CloselistBox2
            // 
            this.CloselistBox2.Location = new System.Drawing.Point(737, 601);
            this.CloselistBox2.Name = "CloselistBox2";
            this.CloselistBox2.Size = new System.Drawing.Size(75, 23);
            this.CloselistBox2.TabIndex = 18;
            this.CloselistBox2.Text = "Close";
            this.CloselistBox2.UseVisualStyleBackColor = true;
            this.CloselistBox2.Visible = false;
            this.CloselistBox2.Click += new System.EventHandler(this.CloselistBox2_Click);
            // 
            // Jump
            // 
            this.Jump.Location = new System.Drawing.Point(738, 572);
            this.Jump.Name = "Jump";
            this.Jump.Size = new System.Drawing.Size(75, 23);
            this.Jump.TabIndex = 17;
            this.Jump.Text = "Jump";
            this.Jump.UseVisualStyleBackColor = true;
            this.Jump.Visible = false;
            this.Jump.Click += new System.EventHandler(this.Jump_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(-3, -5);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(725, 628);
            this.listBox2.TabIndex = 16;
            this.listBox2.Visible = false;
            // 
            // ExitViewer
            // 
            this.ExitViewer.Location = new System.Drawing.Point(531, 572);
            this.ExitViewer.Name = "ExitViewer";
            this.ExitViewer.Size = new System.Drawing.Size(148, 57);
            this.ExitViewer.TabIndex = 15;
            this.ExitViewer.Text = "Exit Viewer";
            this.ExitViewer.UseVisualStyleBackColor = true;
            this.ExitViewer.Click += new System.EventHandler(this.ExitViewer_Click);
            // 
            // View
            // 
            this.View.Location = new System.Drawing.Point(365, 572);
            this.View.Name = "View";
            this.View.Size = new System.Drawing.Size(148, 57);
            this.View.TabIndex = 14;
            this.View.Text = "View Script";
            this.View.UseVisualStyleBackColor = true;
            this.View.Click += new System.EventHandler(this.View_Click);
            // 
            // NameBox
            // 
            this.NameBox.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameBox.Location = new System.Drawing.Point(0, 382);
            this.NameBox.Name = "NameBox";
            this.NameBox.ReadOnly = true;
            this.NameBox.Size = new System.Drawing.Size(205, 39);
            this.NameBox.TabIndex = 11;
            // 
            // dialoguebox
            // 
            this.dialoguebox.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dialoguebox.Location = new System.Drawing.Point(0, 417);
            this.dialoguebox.Name = "dialoguebox";
            this.dialoguebox.ReadOnly = true;
            this.dialoguebox.Size = new System.Drawing.Size(1041, 146);
            this.dialoguebox.TabIndex = 10;
            this.dialoguebox.Text = "";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(376, 50);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(316, 528);
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(200, 50);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(316, 528);
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(613, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(316, 528);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(15, 572);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(148, 57);
            this.Back.TabIndex = 4;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Forward
            // 
            this.Forward.Location = new System.Drawing.Point(189, 572);
            this.Forward.Name = "Forward";
            this.Forward.Size = new System.Drawing.Size(148, 57);
            this.Forward.TabIndex = 3;
            this.Forward.Text = "Forward";
            this.Forward.UseVisualStyleBackColor = true;
            this.Forward.Click += new System.EventHandler(this.Forward_Click);
            // 
            // Background
            // 
            this.Background.Location = new System.Drawing.Point(-3, 0);
            this.Background.Name = "Background";
            this.Background.Size = new System.Drawing.Size(1050, 563);
            this.Background.TabIndex = 0;
            this.Background.TabStop = false;
            // 
            // About
            // 
            this.About.Location = new System.Drawing.Point(417, 320);
            this.About.Name = "About";
            this.About.Size = new System.Drawing.Size(195, 69);
            this.About.TabIndex = 6;
            this.About.Text = "About";
            this.About.UseVisualStyleBackColor = true;
            this.About.Click += new System.EventHandler(this.About_Click);
            // 
            // Editor
            // 
            this.Editor.Location = new System.Drawing.Point(417, 141);
            this.Editor.Name = "Editor";
            this.Editor.Size = new System.Drawing.Size(195, 69);
            this.Editor.TabIndex = 5;
            this.Editor.Text = "Edit";
            this.Editor.UseVisualStyleBackColor = true;
            this.Editor.Click += new System.EventHandler(this.Editor_Click);
            // 
            // Viewer
            // 
            this.Viewer.Location = new System.Drawing.Point(417, 66);
            this.Viewer.Name = "Viewer";
            this.Viewer.Size = new System.Drawing.Size(195, 69);
            this.Viewer.TabIndex = 4;
            this.Viewer.Text = "View Play";
            this.Viewer.UseVisualStyleBackColor = true;
            this.Viewer.Click += new System.EventHandler(this.Viewer_Click);
            // 
            // back2select
            // 
            this.back2select.Location = new System.Drawing.Point(417, 500);
            this.back2select.Name = "back2select";
            this.back2select.Size = new System.Drawing.Size(195, 69);
            this.back2select.TabIndex = 3;
            this.back2select.Text = "Back";
            this.back2select.UseVisualStyleBackColor = true;
            this.back2select.Click += new System.EventHandler(this.back2select_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(556, 58);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(444, 316);
            this.listBox1.TabIndex = 44;
            // 
            // SelectChecked
            // 
            this.SelectChecked.Location = new System.Drawing.Point(925, 382);
            this.SelectChecked.Name = "SelectChecked";
            this.SelectChecked.Size = new System.Drawing.Size(75, 23);
            this.SelectChecked.TabIndex = 43;
            this.SelectChecked.Text = "Select";
            this.SelectChecked.UseVisualStyleBackColor = true;
            this.SelectChecked.Click += new System.EventHandler(this.SelectChecked_Click);
            // 
            // Addplay
            // 
            this.Addplay.Location = new System.Drawing.Point(556, 379);
            this.Addplay.Name = "Addplay";
            this.Addplay.Size = new System.Drawing.Size(75, 23);
            this.Addplay.TabIndex = 42;
            this.Addplay.Text = "Add Play";
            this.Addplay.UseVisualStyleBackColor = true;
            this.Addplay.Click += new System.EventHandler(this.Addplay_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label4.Location = new System.Drawing.Point(734, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 31);
            this.label4.TabIndex = 41;
            this.label4.Text = "Other";
            // 
            // TitusAndronicus
            // 
            this.TitusAndronicus.Location = new System.Drawing.Point(361, 375);
            this.TitusAndronicus.Name = "TitusAndronicus";
            this.TitusAndronicus.Size = new System.Drawing.Size(155, 30);
            this.TitusAndronicus.TabIndex = 39;
            this.TitusAndronicus.Text = "Titus Andronicus";
            this.TitusAndronicus.UseVisualStyleBackColor = true;
            this.TitusAndronicus.Click += new System.EventHandler(this.TitusAndronicus_Click);
            // 
            // TimonofAthens
            // 
            this.TimonofAthens.Location = new System.Drawing.Point(361, 339);
            this.TimonofAthens.Name = "TimonofAthens";
            this.TimonofAthens.Size = new System.Drawing.Size(155, 30);
            this.TimonofAthens.TabIndex = 38;
            this.TimonofAthens.Text = "Timon of Athens";
            this.TimonofAthens.UseVisualStyleBackColor = true;
            this.TimonofAthens.Click += new System.EventHandler(this.TimonofAthens_Click);
            // 
            // RomeoJuliet
            // 
            this.RomeoJuliet.Location = new System.Drawing.Point(361, 303);
            this.RomeoJuliet.Name = "RomeoJuliet";
            this.RomeoJuliet.Size = new System.Drawing.Size(155, 30);
            this.RomeoJuliet.TabIndex = 37;
            this.RomeoJuliet.Text = "Romeo and Juliet";
            this.RomeoJuliet.UseVisualStyleBackColor = true;
            this.RomeoJuliet.Click += new System.EventHandler(this.RomeoJuliet_Click);
            // 
            // Othello
            // 
            this.Othello.Location = new System.Drawing.Point(361, 267);
            this.Othello.Name = "Othello";
            this.Othello.Size = new System.Drawing.Size(155, 30);
            this.Othello.TabIndex = 36;
            this.Othello.Text = "Othello";
            this.Othello.UseVisualStyleBackColor = true;
            this.Othello.Click += new System.EventHandler(this.Othello_Click);
            // 
            // Macbeth
            // 
            this.Macbeth.Location = new System.Drawing.Point(361, 231);
            this.Macbeth.Name = "Macbeth";
            this.Macbeth.Size = new System.Drawing.Size(155, 30);
            this.Macbeth.TabIndex = 35;
            this.Macbeth.Text = "Macbeth";
            this.Macbeth.UseVisualStyleBackColor = true;
            this.Macbeth.Click += new System.EventHandler(this.Macbeth_Click);
            // 
            // KingLear
            // 
            this.KingLear.Location = new System.Drawing.Point(361, 195);
            this.KingLear.Name = "KingLear";
            this.KingLear.Size = new System.Drawing.Size(155, 30);
            this.KingLear.TabIndex = 34;
            this.KingLear.Text = "King Lear";
            this.KingLear.UseVisualStyleBackColor = true;
            this.KingLear.Click += new System.EventHandler(this.KingLear_Click);
            // 
            // JuliusCaesar
            // 
            this.JuliusCaesar.Location = new System.Drawing.Point(361, 159);
            this.JuliusCaesar.Name = "JuliusCaesar";
            this.JuliusCaesar.Size = new System.Drawing.Size(155, 30);
            this.JuliusCaesar.TabIndex = 33;
            this.JuliusCaesar.Text = "Julius Caesar";
            this.JuliusCaesar.UseVisualStyleBackColor = true;
            this.JuliusCaesar.Click += new System.EventHandler(this.JuliusCaesar_Click);
            // 
            // Coriolanus
            // 
            this.Coriolanus.Location = new System.Drawing.Point(361, 85);
            this.Coriolanus.Name = "Coriolanus";
            this.Coriolanus.Size = new System.Drawing.Size(155, 30);
            this.Coriolanus.TabIndex = 32;
            this.Coriolanus.Text = "Coriolanus";
            this.Coriolanus.UseVisualStyleBackColor = true;
            this.Coriolanus.Click += new System.EventHandler(this.Coriolanus_Click);
            // 
            // AntonyandCleopatra
            // 
            this.AntonyandCleopatra.Location = new System.Drawing.Point(361, 49);
            this.AntonyandCleopatra.Name = "AntonyandCleopatra";
            this.AntonyandCleopatra.Size = new System.Drawing.Size(155, 30);
            this.AntonyandCleopatra.TabIndex = 31;
            this.AntonyandCleopatra.Text = "Antony and Cleopatra";
            this.AntonyandCleopatra.UseVisualStyleBackColor = true;
            this.AntonyandCleopatra.Click += new System.EventHandler(this.AntonyandCleopatra_Click);
            // 
            // Richardthird
            // 
            this.Richardthird.Location = new System.Drawing.Point(185, 375);
            this.Richardthird.Name = "Richardthird";
            this.Richardthird.Size = new System.Drawing.Size(155, 30);
            this.Richardthird.TabIndex = 30;
            this.Richardthird.Text = "Richard III";
            this.Richardthird.UseVisualStyleBackColor = true;
            this.Richardthird.Click += new System.EventHandler(this.Richardthird_Click);
            // 
            // Richardsecond
            // 
            this.Richardsecond.Location = new System.Drawing.Point(185, 339);
            this.Richardsecond.Name = "Richardsecond";
            this.Richardsecond.Size = new System.Drawing.Size(155, 30);
            this.Richardsecond.TabIndex = 29;
            this.Richardsecond.Text = "Richard II";
            this.Richardsecond.UseVisualStyleBackColor = true;
            this.Richardsecond.Click += new System.EventHandler(this.Richardsecond_Click);
            // 
            // KingJohn
            // 
            this.KingJohn.Location = new System.Drawing.Point(185, 303);
            this.KingJohn.Name = "KingJohn";
            this.KingJohn.Size = new System.Drawing.Size(155, 30);
            this.KingJohn.TabIndex = 28;
            this.KingJohn.Text = "King John";
            this.KingJohn.UseVisualStyleBackColor = true;
            this.KingJohn.Click += new System.EventHandler(this.KingJohn_Click);
            // 
            // Henry8
            // 
            this.Henry8.Location = new System.Drawing.Point(185, 267);
            this.Henry8.Name = "Henry8";
            this.Henry8.Size = new System.Drawing.Size(155, 30);
            this.Henry8.TabIndex = 27;
            this.Henry8.Text = "Henry VIII";
            this.Henry8.UseVisualStyleBackColor = true;
            this.Henry8.Click += new System.EventHandler(this.Henry8_Click);
            // 
            // Henry6part3
            // 
            this.Henry6part3.Location = new System.Drawing.Point(185, 231);
            this.Henry6part3.Name = "Henry6part3";
            this.Henry6part3.Size = new System.Drawing.Size(155, 30);
            this.Henry6part3.TabIndex = 26;
            this.Henry6part3.Text = "Henry VI, part 3";
            this.Henry6part3.UseVisualStyleBackColor = true;
            this.Henry6part3.Click += new System.EventHandler(this.Henry6part3_Click);
            // 
            // Henry6part2
            // 
            this.Henry6part2.Location = new System.Drawing.Point(185, 195);
            this.Henry6part2.Name = "Henry6part2";
            this.Henry6part2.Size = new System.Drawing.Size(155, 30);
            this.Henry6part2.TabIndex = 25;
            this.Henry6part2.Text = "Henry VI, part 2";
            this.Henry6part2.UseVisualStyleBackColor = true;
            this.Henry6part2.Click += new System.EventHandler(this.Henry6part2_Click);
            // 
            // Henry6part1
            // 
            this.Henry6part1.Location = new System.Drawing.Point(185, 159);
            this.Henry6part1.Name = "Henry6part1";
            this.Henry6part1.Size = new System.Drawing.Size(155, 30);
            this.Henry6part1.TabIndex = 24;
            this.Henry6part1.Text = "Henry VI, part 1";
            this.Henry6part1.UseVisualStyleBackColor = true;
            this.Henry6part1.Click += new System.EventHandler(this.Henry6part1_Click);
            // 
            // Henry5
            // 
            this.Henry5.Location = new System.Drawing.Point(185, 123);
            this.Henry5.Name = "Henry5";
            this.Henry5.Size = new System.Drawing.Size(155, 30);
            this.Henry5.TabIndex = 23;
            this.Henry5.Text = "Henry V";
            this.Henry5.UseVisualStyleBackColor = true;
            this.Henry5.Click += new System.EventHandler(this.Henry5_Click);
            // 
            // Henry4part2
            // 
            this.Henry4part2.Location = new System.Drawing.Point(185, 87);
            this.Henry4part2.Name = "Henry4part2";
            this.Henry4part2.Size = new System.Drawing.Size(155, 30);
            this.Henry4part2.TabIndex = 22;
            this.Henry4part2.Text = "Henry IV, part 2";
            this.Henry4part2.UseVisualStyleBackColor = true;
            this.Henry4part2.Click += new System.EventHandler(this.Henry4part2_Click);
            // 
            // Henry4part1
            // 
            this.Henry4part1.Location = new System.Drawing.Point(185, 49);
            this.Henry4part1.Name = "Henry4part1";
            this.Henry4part1.Size = new System.Drawing.Size(155, 30);
            this.Henry4part1.TabIndex = 21;
            this.Henry4part1.Text = "Henry IV, part 1";
            this.Henry4part1.UseVisualStyleBackColor = true;
            this.Henry4part1.Click += new System.EventHandler(this.Henry4part1_Click);
            // 
            // WintersTale
            // 
            this.WintersTale.Location = new System.Drawing.Point(11, 591);
            this.WintersTale.Name = "WintersTale";
            this.WintersTale.Size = new System.Drawing.Size(155, 30);
            this.WintersTale.TabIndex = 20;
            this.WintersTale.Text = "Winter\'s Tale";
            this.WintersTale.UseVisualStyleBackColor = true;
            this.WintersTale.Click += new System.EventHandler(this.WintersTale_Click);
            // 
            // GentlemenofVerona
            // 
            this.GentlemenofVerona.Location = new System.Drawing.Point(11, 555);
            this.GentlemenofVerona.Name = "GentlemenofVerona";
            this.GentlemenofVerona.Size = new System.Drawing.Size(155, 30);
            this.GentlemenofVerona.TabIndex = 19;
            this.GentlemenofVerona.Text = "Two Gentlemen of Verona";
            this.GentlemenofVerona.UseVisualStyleBackColor = true;
            this.GentlemenofVerona.Click += new System.EventHandler(this.GentlemenofVerona_Click);
            // 
            // TwelfthNight
            // 
            this.TwelfthNight.Location = new System.Drawing.Point(11, 519);
            this.TwelfthNight.Name = "TwelfthNight";
            this.TwelfthNight.Size = new System.Drawing.Size(155, 30);
            this.TwelfthNight.TabIndex = 18;
            this.TwelfthNight.Text = "Twelfth Night";
            this.TwelfthNight.UseVisualStyleBackColor = true;
            this.TwelfthNight.Click += new System.EventHandler(this.TwelfthNight_Click);
            // 
            // TroilusandCressida
            // 
            this.TroilusandCressida.Location = new System.Drawing.Point(11, 483);
            this.TroilusandCressida.Name = "TroilusandCressida";
            this.TroilusandCressida.Size = new System.Drawing.Size(155, 30);
            this.TroilusandCressida.TabIndex = 17;
            this.TroilusandCressida.Text = "Troilus and Cressida";
            this.TroilusandCressida.UseVisualStyleBackColor = true;
            this.TroilusandCressida.Click += new System.EventHandler(this.TroilusandCressida_Click);
            // 
            // TheTempest
            // 
            this.TheTempest.Location = new System.Drawing.Point(11, 447);
            this.TheTempest.Name = "TheTempest";
            this.TheTempest.Size = new System.Drawing.Size(155, 30);
            this.TheTempest.TabIndex = 16;
            this.TheTempest.Text = "The Tempest";
            this.TheTempest.UseVisualStyleBackColor = true;
            this.TheTempest.Click += new System.EventHandler(this.TheTempest_Click);
            // 
            // TamingoftheShrew
            // 
            this.TamingoftheShrew.Location = new System.Drawing.Point(11, 411);
            this.TamingoftheShrew.Name = "TamingoftheShrew";
            this.TamingoftheShrew.Size = new System.Drawing.Size(155, 30);
            this.TamingoftheShrew.TabIndex = 15;
            this.TamingoftheShrew.Text = "Taming of the Shrew";
            this.TamingoftheShrew.UseVisualStyleBackColor = true;
            this.TamingoftheShrew.Click += new System.EventHandler(this.TamingoftheShrew_Click);
            // 
            // Pericles
            // 
            this.Pericles.Location = new System.Drawing.Point(11, 375);
            this.Pericles.Name = "Pericles";
            this.Pericles.Size = new System.Drawing.Size(155, 30);
            this.Pericles.TabIndex = 14;
            this.Pericles.Text = "Pericles, Prince of Tyre";
            this.Pericles.UseVisualStyleBackColor = true;
            this.Pericles.Click += new System.EventHandler(this.Pericles_Click);
            // 
            // MuchAdo
            // 
            this.MuchAdo.Location = new System.Drawing.Point(11, 339);
            this.MuchAdo.Name = "MuchAdo";
            this.MuchAdo.Size = new System.Drawing.Size(155, 30);
            this.MuchAdo.TabIndex = 13;
            this.MuchAdo.Text = "Much Ado About Nothing";
            this.MuchAdo.UseVisualStyleBackColor = true;
            this.MuchAdo.Click += new System.EventHandler(this.MuchAdo_Click);
            // 
            // MidsummerNights
            // 
            this.MidsummerNights.Location = new System.Drawing.Point(11, 303);
            this.MidsummerNights.Name = "MidsummerNights";
            this.MidsummerNights.Size = new System.Drawing.Size(155, 30);
            this.MidsummerNights.TabIndex = 12;
            this.MidsummerNights.Text = "A Midsummer Night\'s Dream";
            this.MidsummerNights.UseVisualStyleBackColor = true;
            this.MidsummerNights.Click += new System.EventHandler(this.MidsummerNights_Click);
            // 
            // MerchantofVenice
            // 
            this.MerchantofVenice.Location = new System.Drawing.Point(11, 267);
            this.MerchantofVenice.Name = "MerchantofVenice";
            this.MerchantofVenice.Size = new System.Drawing.Size(155, 30);
            this.MerchantofVenice.TabIndex = 11;
            this.MerchantofVenice.Text = "The Merchant of Venice";
            this.MerchantofVenice.UseVisualStyleBackColor = true;
            this.MerchantofVenice.Click += new System.EventHandler(this.MerchantofVenice_Click);
            // 
            // MerryWives
            // 
            this.MerryWives.Location = new System.Drawing.Point(11, 231);
            this.MerryWives.Name = "MerryWives";
            this.MerryWives.Size = new System.Drawing.Size(155, 30);
            this.MerryWives.TabIndex = 10;
            this.MerryWives.Text = "The Merry Wives of Windsor";
            this.MerryWives.UseVisualStyleBackColor = true;
            this.MerryWives.Click += new System.EventHandler(this.MerryWives_Click);
            // 
            // LovesLaboursLost
            // 
            this.LovesLaboursLost.Location = new System.Drawing.Point(11, 195);
            this.LovesLaboursLost.Name = "LovesLaboursLost";
            this.LovesLaboursLost.Size = new System.Drawing.Size(155, 30);
            this.LovesLaboursLost.TabIndex = 9;
            this.LovesLaboursLost.Text = "Love\'s  Labours Lost";
            this.LovesLaboursLost.UseVisualStyleBackColor = true;
            this.LovesLaboursLost.Click += new System.EventHandler(this.LovesLaboursLost_Click);
            // 
            // Cymbeline
            // 
            this.Cymbeline.Location = new System.Drawing.Point(11, 159);
            this.Cymbeline.Name = "Cymbeline";
            this.Cymbeline.Size = new System.Drawing.Size(155, 30);
            this.Cymbeline.TabIndex = 8;
            this.Cymbeline.Text = "Cymbeline";
            this.Cymbeline.UseVisualStyleBackColor = true;
            this.Cymbeline.Click += new System.EventHandler(this.Cymbeline_Click);
            // 
            // ComedyofErrors
            // 
            this.ComedyofErrors.Location = new System.Drawing.Point(11, 123);
            this.ComedyofErrors.Name = "ComedyofErrors";
            this.ComedyofErrors.Size = new System.Drawing.Size(155, 30);
            this.ComedyofErrors.TabIndex = 7;
            this.ComedyofErrors.Text = "The Comedy of Errors";
            this.ComedyofErrors.UseVisualStyleBackColor = true;
            this.ComedyofErrors.Click += new System.EventHandler(this.ComedyofErrors_Click);
            // 
            // AsYouLikeIt
            // 
            this.AsYouLikeIt.Location = new System.Drawing.Point(11, 87);
            this.AsYouLikeIt.Name = "AsYouLikeIt";
            this.AsYouLikeIt.Size = new System.Drawing.Size(155, 30);
            this.AsYouLikeIt.TabIndex = 6;
            this.AsYouLikeIt.Text = "As You Like It";
            this.AsYouLikeIt.UseVisualStyleBackColor = true;
            this.AsYouLikeIt.Click += new System.EventHandler(this.AsYouLikeIt_Click);
            // 
            // AllsWell
            // 
            this.AllsWell.Location = new System.Drawing.Point(11, 49);
            this.AllsWell.Name = "AllsWell";
            this.AllsWell.Size = new System.Drawing.Size(155, 30);
            this.AllsWell.TabIndex = 5;
            this.AllsWell.Text = "All\'s Well That Ends Well";
            this.AllsWell.UseVisualStyleBackColor = true;
            this.AllsWell.Click += new System.EventHandler(this.AllsWell_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label3.Location = new System.Drawing.Point(388, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 31);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tragedy";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label2.Location = new System.Drawing.Point(218, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "History";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label1.Location = new System.Drawing.Point(34, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Comedy";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(871, 537);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(129, 66);
            this.button5.TabIndex = 1;
            this.button5.Text = "Back";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // Hamlet
            // 
            this.Hamlet.Location = new System.Drawing.Point(361, 123);
            this.Hamlet.Name = "Hamlet";
            this.Hamlet.Size = new System.Drawing.Size(155, 30);
            this.Hamlet.TabIndex = 0;
            this.Hamlet.Text = "Hamlet";
            this.Hamlet.UseVisualStyleBackColor = true;
            this.Hamlet.Click += new System.EventHandler(this.Hamlet_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(717, 300);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(195, 69);
            this.button4.TabIndex = 2;
            this.button4.Text = "Back";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(717, 200);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(195, 69);
            this.button3.TabIndex = 1;
            this.button3.Text = "Select Play";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(717, 300);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(195, 69);
            this.button2.TabIndex = 1;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 636);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.previewBox)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Background)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Hamlet;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button WintersTale;
        private System.Windows.Forms.Button GentlemenofVerona;
        private System.Windows.Forms.Button TwelfthNight;
        private System.Windows.Forms.Button TroilusandCressida;
        private System.Windows.Forms.Button TheTempest;
        private System.Windows.Forms.Button TamingoftheShrew;
        private System.Windows.Forms.Button Pericles;
        private System.Windows.Forms.Button MuchAdo;
        private System.Windows.Forms.Button MidsummerNights;
        private System.Windows.Forms.Button MerchantofVenice;
        private System.Windows.Forms.Button MerryWives;
        private System.Windows.Forms.Button LovesLaboursLost;
        private System.Windows.Forms.Button Cymbeline;
        private System.Windows.Forms.Button ComedyofErrors;
        private System.Windows.Forms.Button AsYouLikeIt;
        private System.Windows.Forms.Button AllsWell;
        private System.Windows.Forms.Button TitusAndronicus;
        private System.Windows.Forms.Button TimonofAthens;
        private System.Windows.Forms.Button RomeoJuliet;
        private System.Windows.Forms.Button Othello;
        private System.Windows.Forms.Button Macbeth;
        private System.Windows.Forms.Button KingLear;
        private System.Windows.Forms.Button JuliusCaesar;
        private System.Windows.Forms.Button Coriolanus;
        private System.Windows.Forms.Button AntonyandCleopatra;
        private System.Windows.Forms.Button Richardthird;
        private System.Windows.Forms.Button Richardsecond;
        private System.Windows.Forms.Button KingJohn;
        private System.Windows.Forms.Button Henry8;
        private System.Windows.Forms.Button Henry6part3;
        private System.Windows.Forms.Button Henry6part2;
        private System.Windows.Forms.Button Henry6part1;
        private System.Windows.Forms.Button Henry5;
        private System.Windows.Forms.Button Henry4part2;
        private System.Windows.Forms.Button Henry4part1;
        private System.Windows.Forms.Button Addplay;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button SelectChecked;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button back2select;
        private System.Windows.Forms.Button About;
        private System.Windows.Forms.Button Editor;
        private System.Windows.Forms.Button Viewer;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Forward;
        private System.Windows.Forms.PictureBox Background;
        private System.Windows.Forms.TextBox NameBox;
        private System.Windows.Forms.RichTextBox dialoguebox;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button ExitViewer;
        private System.Windows.Forms.Button View;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button CloselistBox2;
        private System.Windows.Forms.Button Jump;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Button editscript;
        private System.Windows.Forms.Button backfromedit;
        private System.Windows.Forms.Button editsettings;
        private System.Windows.Forms.Button editplayers;
        private System.Windows.Forms.RichTextBox Script;
        private System.Windows.Forms.PictureBox previewBox;
        private System.Windows.Forms.Button scriptbutton;
        private System.Windows.Forms.Button Default;
        private System.Windows.Forms.Button imageedit;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.RichTextBox StageDirections;
    }
}

